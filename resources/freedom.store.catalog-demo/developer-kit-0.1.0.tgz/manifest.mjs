const contractPattern = /^.+@[1-9]\d*$/;
export function validateManifest(value) {
  const manifest = structuredClone(value);
  if (!manifest || !/^[a-z0-9][a-z0-9._-]*$/.test(manifest.id ?? '') || typeof manifest.version !== 'string' || !manifest.version.trim() || typeof manifest.name !== 'string' || !manifest.name.trim()) throw new Error('A module needs an id, name and version.');
  manifest.provides ??= []; manifest.requires ??= [];
  if (!Array.isArray(manifest.provides) || !Array.isArray(manifest.requires)) throw new Error('Invalid module contracts.');
  const seen = new Set();
  for (const service of manifest.provides) {
    if (!contractPattern.test(service.contract ?? '') || seen.has(service.contract) || !Array.isArray(service.methods) || !service.methods.length || service.methods.some(method => typeof method !== 'string' || !method)) throw new Error('Invalid provided contract.');
    seen.add(service.contract);
  }
  for (const item of manifest.requires) if (!contractPattern.test((typeof item === 'string' ? item : item?.contract) ?? '')) throw new Error('Invalid required contract.');
  return manifest;
}
