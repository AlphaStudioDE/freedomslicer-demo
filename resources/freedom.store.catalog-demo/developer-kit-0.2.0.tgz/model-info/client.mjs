export async function activate(context) {
  let panel;
  function show(model) {
    if (!panel) return;
    panel.replaceChildren();
    const heading = document.createElement('h2'); heading.textContent = 'Model info';
    heading.style.cssText = 'font-size:20px;font-weight:450;margin:0 0 12px';
    const note = document.createElement('p'); note.textContent = 'An independent store extension. This panel follows the active model.';
    note.style.cssText = 'font-size:10px;line-height:1.7;color:#8fa8ae;margin-bottom:24px';
    panel.append(heading, note);
    if (!model) { const empty = document.createElement('p'); empty.textContent = 'Load a model to inspect it.'; panel.append(empty); return; }
    const name = document.createElement('strong'); name.textContent = model.name; name.style.cssText = 'font-size:12px;overflow-wrap:anywhere'; panel.append(name);
    const list = document.createElement('dl'); list.style.cssText = 'font-size:11px;line-height:1.7;margin-top:25px';
    for (const [label, value] of [['Width', `${model.dimensions[0].toFixed(2)} mm`], ['Depth', `${model.dimensions[1].toFixed(2)} mm`], ['Height', `${model.dimensions[2].toFixed(2)} mm`], ['Triangles', model.triangles.toLocaleString('en')], ['File size', `${(model.bytes / 1024).toFixed(1)} KB`]]) {
      const term = document.createElement('dt'); term.textContent = label; term.style.color = '#8fa8ae';
      const detail = document.createElement('dd'); detail.textContent = value; detail.style.cssText = 'margin:2px 0 19px;color:#d8e7d0'; list.append(term, detail);
    }
    panel.append(list);
  }
  let model = await context.call('freedom.document.model@1', 'get');
  await context.call('freedom.ui.panels@1', 'add', { id: 'summary', label: 'Model info', symbol: 'ⓘ', render(element) { panel = element; show(model); } });
  await context.call('freedom.document.model@1', 'subscribe', value => { model = value; show(model); });
  return { services: {} };
}
