import { build } from 'esbuild';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, dirname, relative, isAbsolute } from 'node:path';
import { pathToFileURL } from 'node:url';
import { validateManifest } from './manifest.mjs';

export async function packModule(directory, output) {
  directory = resolve(directory);
  const manifest = validateManifest(JSON.parse(await readFile(resolve(directory, 'module.json'), 'utf8')));
  if (typeof manifest.entry !== 'string') throw new Error('The author manifest needs a browser entry file.');
  const entry = resolve(directory, manifest.entry); const part = relative(directory, entry);
  if (part.startsWith('..') || isAbsolute(part)) throw new Error('Entry must be inside the submitted module directory.');
  const result = await build({ entryPoints: [entry], bundle: true, platform: 'browser', format: 'esm', target: 'es2022',
    write: false, minify: true, sourcemap: false, legalComments: 'inline', metafile: true });
  if (Object.values(result.metafile.outputs).some(item => item.imports.length)) throw new Error('Package browser dependencies in the module bundle.');
  const pkg = { format: 'freedom.browser-package@1', manifest, code: result.outputFiles[0].text };
  const data = `${JSON.stringify(pkg, null, 2)}\n`;
  if (output) { await mkdir(dirname(resolve(output)), { recursive: true }); await writeFile(output, data); }
  return { package: pkg, data, inputs: Object.keys(result.metafile.inputs) };
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  if (!process.argv[2] || !process.argv[3]) throw new Error('Usage: node sdk/pack.mjs <author-directory> <submission.json>');
  await packModule(process.argv[2], process.argv[3]); console.log(`Submission prepared: ${resolve(process.argv[3])}`);
}
