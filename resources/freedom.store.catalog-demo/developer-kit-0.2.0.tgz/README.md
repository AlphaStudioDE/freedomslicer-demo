# FreedomSlicer author kit 0.2

This experimental SDK prepares browser module submissions for the official FreedomSlicer store. All user extension installations, including free modules, go through that store. Local-file installation and arbitrary package URLs are not supported. Paid modules are sold exclusively through the store, with a platform commission; the platform commission is 20%. Paid offers remain disabled until commercial setup is completed.

The sample is an independent Model info panel. It reads the active model through a documented service and registers a panel through another service. It imports no FreedomSlicer application or engine code.

## Prepare a submission

Requires Node.js 22+ and npm. Extract this archive to your own directory:

```sh
npm install
npm run pack
```

The output is `submission.json`. This prepares an author submission; it does not publish or install the extension. The current demonstration catalog is curated manually. Publisher accounts, online submission, review and purchases are planned backend capabilities.

For a different module directory:

```sh
node pack.mjs path/to/my-module my-submission.json
```

## Module contract

`module.json` declares `id`, `name`, `version`, `entry`, `provides` and `requires`. Contract names use `name@majorVersion`. Authors may define new services, methods and data formats. Optional publisher metadata is informational; store pricing and seller identity must be authoritative in the store backend.

Export `async activate(context)` returning `{services, dispose?}`. Use `context.call(contract, method, input, {provider}?)`, `context.discover({contract?,features?})`, `context.own(cleanup)` and `context.signal`. Declared methods must have implementations. Dependency activation and cleanup are managed by the browser execution adapter.

`freedom.document.model@1`: `get()` returns a copy of `{id,name,bytes,dimensions:[x,y,z],triangles,units:"mm"}` or null; `subscribe(callback)` sends current and subsequent snapshots. Subscriptions are scoped to module lifetime.

`freedom.ui.panels@1`: `add({id,label,symbol?,render(container)})` creates a panel and navigation action. Both are removed when the module is disabled. Read the sample for a complete implementation.

The browser SDK runs author code in an opaque sandbox frame. Its DOM is the extension view, not the platform page. Callbacks and service calls cross a scoped message bridge. Await context.discover(). Direct parent DOM, platform storage and network access are unavailable. The official store and installer cannot be replaced by extensions; selling modules through another extension is forbidden. Commerce declarations may list non-module products, for example commerce: {products: ["models"]}. Platform identities and freedom.store / freedom.extensions contracts are reserved. This release does not yet provide an external-commerce network capability. It is not a process RPC protocol. It does not contain private application host sources, commerce credentials or purchase enforcement. Source maps are omitted from submissions. Third-party dependencies must carry their required license notices.
