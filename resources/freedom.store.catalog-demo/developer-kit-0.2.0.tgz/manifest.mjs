const contractPattern = /^.+@[1-9]\d*$/;
export function isProtectedContract(contract) {
  const name = String(contract).split('@')[0];
  return ['freedom.store','freedom.extensions'].some(prefix => name === prefix || name.startsWith(`${prefix}.`));
}
export function validateManifest(value) {
  const manifest = structuredClone(value);
  if (!manifest || typeof manifest.id !== 'string' || !/^[a-z0-9][a-z0-9._-]*$/.test(manifest.id) || typeof manifest.version !== 'string' || !manifest.version.trim() || typeof manifest.name !== 'string' || !manifest.name.trim()) throw new Error('A module needs an id, name and version.');
  manifest.provides ??= []; manifest.requires ??= [];
  if(manifest.dependencies!==undefined){
    if(!Array.isArray(manifest.dependencies)||manifest.dependencies.length>128)throw new Error('Invalid store dependencies.');
    for(const dep of manifest.dependencies)if(!dep||typeof dep.id!=='string'||!/^[a-z0-9][a-z0-9._-]*$/.test(dep.id)||typeof dep.version!=='string'||!dep.version.trim()||typeof dep.optional!=='boolean'||(dep.description!==undefined&&typeof dep.description!=='string'))throw new Error('Declare store dependency id, exact version and optional flag.');
  }
  if (manifest.id === 'freedom' || manifest.id.startsWith('freedom.')) throw new Error('The freedom namespace belongs to the platform, not third-party extensions.');
  if (manifest.commerce !== undefined) {
    const products = manifest.commerce?.products;
    if (!Array.isArray(products) || products.some(kind => typeof kind !== 'string' || !kind.trim())) throw new Error('Declare the non-module products sold by a commerce extension.');
    if (products.some(kind => ['module','modules','extension','extensions','plugin','plugins','module-marketplace'].includes(kind.trim().toLowerCase()))) throw new Error('Extensions cannot sell modules. Module sales belong exclusively to the official store.');
  }
  if (!Array.isArray(manifest.provides) || !Array.isArray(manifest.requires)) throw new Error('Invalid module contracts.');
  const seen = new Set();
  for (const service of manifest.provides) {
    if (isProtectedContract(service?.contract)) throw new Error('Extensions cannot replace the official store, installer, module payments or module licensing.');
    if (!service || !contractPattern.test(service.contract ?? '') || seen.has(service.contract) || !Array.isArray(service.methods) || !service.methods.length || service.methods.some(method => typeof method !== 'string' || !method)) throw new Error('Invalid provided contract.');
    seen.add(service.contract);
  }
  for (const item of manifest.requires) if (!contractPattern.test((typeof item === 'string' ? item : item?.contract) ?? '')) throw new Error('Invalid required contract.');
  return manifest;
}
